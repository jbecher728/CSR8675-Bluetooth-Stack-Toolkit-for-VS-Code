# Notes

This stack assumes a **module-centric** design:

- The CSR8675 module already carries its proprietary Bluetooth/HFP firmware.
- The host stack controls that module over UART and interprets its status indications.
- The host stack does not claim to replace Qualcomm's internal build and tuning chain.

## Typical integration path

1. Identify the real UART command set of your module.
2. Clone `scripts/csr8675_i2s_generic.json`.
3. Fill in command strings and known status indication prefixes.
4. Test with `csr8675ctl raw` and `csr8675ctl monitor`.
5. Bind host outputs to your keypad/display/LED hardware.

## I2S assumptions

The I2S settings in this project are **host-side integration metadata**, not proof that your module firmware allows those exact settings. Verify your module's actual clocking mode, bit depth, and sample-rate support.

## Safety and honesty

This repository is meant to accelerate a buildable DIY architecture. It is not a claim of full firmware-level compatibility with Qualcomm's ADK.
