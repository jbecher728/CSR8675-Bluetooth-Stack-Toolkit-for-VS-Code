# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from __future__ import annotations

import argparse
from pathlib import Path

from .controller import ModuleController
from .profiles import DeviceProfile
from .serial_transport import SerialTransport, list_serial_ports
from .simulator import build_simulator, run_script
from .state import HostState


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="csr8675ctl")
    parser.add_argument("--port", help="Serial port for module access")
    parser.add_argument("--profile", help="Path to JSON module profile")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("ports", help="List serial ports")
    sub.add_parser("info", help="Send info command")
    sub.add_parser("monitor", help="Read lines from the module until timeout")
    raw = sub.add_parser("raw", help="Send a raw command")
    raw.add_argument("text")
    sim = sub.add_parser("simulate", help="Run key-script simulation")
    sim.add_argument("--script", required=True)
    key = sub.add_parser("key", help="Inject one key into the host state machine")
    key.add_argument("key")
    sub.add_parser("validate-i2s", help="Validate I2S profile config")
    return parser


def load_profile(path: str | None) -> DeviceProfile:
    return DeviceProfile.from_json(path) if path else DeviceProfile()


def make_controller(args: argparse.Namespace) -> ModuleController:
    profile = load_profile(args.profile)
    if not args.port:
        raise SystemExit("--port is required for this command")
    transport = SerialTransport(args.port, baudrate=profile.baudrate, timeout=profile.timeout)
    return ModuleController(transport, profile, HostState(i2s=profile.i2s))


def main() -> None:
    args = build_parser().parse_args()
    profile = load_profile(getattr(args, "profile", None))
    if args.command == "ports":
        for port in list_serial_ports():
            print(port)
        return
    if args.command == "simulate":
        result = run_script(Path(args.script), profile)
        print(result.rendered)
        print("\nCommands:")
        for command in result.commands:
            print(command.rstrip())
        return
    if args.command == "validate-i2s":
        issues = profile.i2s.validate()
        print(profile.i2s.summary())
        if issues:
            print("Issues:")
            for issue in issues:
                print(f"- {issue}")
        else:
            print("No config issues detected.")
        return
    if args.command == "key":
        controller = build_simulator(profile)
        print(controller.handle_key(args.key))
        return
    controller = make_controller(args)
    if args.command == "info":
        print(controller.info())
    elif args.command == "raw":
        print(controller.transport.exchange(args.text, profile.line_ending))
    elif args.command == "monitor":
        for line in controller.transport.monitor():
            event = controller.apply_line(line)
            print(f"[{event.kind}] {line}")
            print(controller.state.render())


if __name__ == "__main__":
    main()
