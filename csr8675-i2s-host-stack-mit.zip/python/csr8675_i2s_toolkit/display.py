# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class DisplayBuffer:
    width: int = 22
    height: int = 8
    rows: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.rows:
            self.rows = [" " * self.width for _ in range(self.height)]

    def clear(self) -> None:
        self.rows = [" " * self.width for _ in range(self.height)]

    def write(self, row: int, col: int, text: str) -> None:
        if row < 0 or row >= self.height:
            return
        line = list(self.rows[row])
        for offset, char in enumerate(text):
            index = col + offset
            if 0 <= index < self.width:
                line[index] = char
        self.rows[row] = "".join(line)

    def write_centered(self, row: int, text: str) -> None:
        start = max((self.width - len(text)) // 2, 0)
        self.write(row, start, text[: self.width])

    def render(self) -> str:
        border = "+" + "-" * self.width + "+"
        body = "\n".join("|" + row + "|" for row in self.rows)
        return f"{border}\n{body}\n{border}"
