# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .audio import I2SConfig


@dataclass(slots=True)
class DeviceProfile:
    name: str = "csr8675-i2s-generic"
    baudrate: int = 115200
    line_ending: str = "\r\n"
    timeout: float = 1.0
    commands: dict[str, str] = field(default_factory=lambda: {
        "info": "AT+INFO?",
        "answer": "ATA",
        "hangup": "ATH",
        "dial": "ATD{number};",
        "redial": "AT+BLDN",
        "volume_up": "AT+VOLUP",
        "volume_down": "AT+VOLDOWN",
        "query_signal": "AT+CSQ?",
        "query_link": "AT+LINK?",
        "query_name": "AT+NAME?",
    })
    event_prefixes: dict[str, str] = field(default_factory=lambda: {
        "incoming_call": "RING",
        "caller_id": "+CLIP:",
        "call_active": "CALL ACTIVE",
        "call_ended": "NO CARRIER",
        "linked": "CONNECTED",
        "unlinked": "DISCONNECTED",
        "ok": "OK",
        "error": "ERROR",
    })
    i2s: I2SConfig = field(default_factory=I2SConfig)

    @classmethod
    def from_json(cls, path: str | Path) -> "DeviceProfile":
        payload: dict[str, Any] = json.loads(Path(path).read_text(encoding="utf-8"))
        i2s_payload = payload.pop("i2s", {})
        profile = cls(**payload)
        profile.i2s = I2SConfig(**i2s_payload)
        return profile

    def render_command(self, key: str, **kwargs: str) -> str:
        template = self.commands[key]
        return template.format(**kwargs)
