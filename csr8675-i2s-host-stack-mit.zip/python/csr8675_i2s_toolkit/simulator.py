# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .controller import MockTransport, ModuleController
from .profiles import DeviceProfile
from .state import HostState


@dataclass(slots=True)
class SimulationResult:
    final_screen: str
    rendered: str
    commands: list[str]


def build_simulator(profile: DeviceProfile | None = None) -> ModuleController:
    active_profile = profile or DeviceProfile()
    state = HostState(i2s=active_profile.i2s)
    return ModuleController(MockTransport(), active_profile, state)


def run_script(script_path: str | Path, profile: DeviceProfile | None = None) -> SimulationResult:
    controller = build_simulator(profile)
    for raw in Path(script_path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        controller.handle_key(line)
    return SimulationResult(controller.state.screen.value, controller.state.render(), list(controller.transport.history))
