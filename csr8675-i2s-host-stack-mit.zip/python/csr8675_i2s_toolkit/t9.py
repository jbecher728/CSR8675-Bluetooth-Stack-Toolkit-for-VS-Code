# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from __future__ import annotations

from dataclasses import dataclass, field

T9_MAP = {"2": "ABC", "3": "DEF", "4": "GHI", "5": "JKL", "6": "MNO", "7": "PQRS", "8": "TUV", "9": "WXYZ", "0": " ", "1": "1"}


@dataclass(slots=True)
class T9Composer:
    text: str = ""
    last_digit: str | None = None
    cycle_index: int = 0
    pending: bool = False
    history: list[str] = field(default_factory=list)

    def press(self, digit: str) -> str:
        if digit not in T9_MAP:
            raise ValueError(f"digit {digit} is not valid for T9")
        chars = T9_MAP[digit]
        if self.pending and self.last_digit == digit and len(chars) > 0:
            self.cycle_index = (self.cycle_index + 1) % len(chars)
            self.text = self.text[:-1] + chars[self.cycle_index]
        else:
            self.last_digit = digit
            self.cycle_index = 0
            self.pending = True
            self.text += chars[self.cycle_index]
        self.history.append(self.text)
        return self.text

    def commit(self) -> str:
        self.pending = False
        self.last_digit = None
        self.cycle_index = 0
        return self.text

    def backspace(self) -> str:
        if self.text:
            self.text = self.text[:-1]
        self.pending = False
        self.last_digit = None
        self.cycle_index = 0
        self.history.append(self.text)
        return self.text
