// SPDX-License-Identifier: MIT
// Copyright (c) 2026 OpenAI

#include "display.hpp"

#include <sstream>

namespace csr8675 {

DisplayBuffer::DisplayBuffer(int width, int height) : width_(width), height_(height), rows_(height, std::string(width, ' ')) {}

void DisplayBuffer::clear() {
    rows_.assign(height_, std::string(width_, ' '));
}

void DisplayBuffer::write(int row, int col, const std::string& text) {
    if (row < 0 || row >= height_) return;
    for (std::size_t i = 0; i < text.size(); ++i) {
        int j = col + static_cast<int>(i);
        if (j >= 0 && j < width_) {
            rows_[row][j] = text[i];
        }
    }
}

std::string DisplayBuffer::render() const {
    std::ostringstream out;
    out << "+" << std::string(width_, '-') << "+\n";
    for (const auto& row : rows_) {
        out << "|" << row << "|\n";
    }
    out << "+" << std::string(width_, '-') << "+\n";
    return out.str();
}

}  // namespace csr8675
