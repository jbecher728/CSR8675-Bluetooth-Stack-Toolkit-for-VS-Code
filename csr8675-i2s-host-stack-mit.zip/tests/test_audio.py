# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from csr8675_i2s_toolkit.audio import I2SConfig


def test_i2s_validate_ok() -> None:
    cfg = I2SConfig(enabled=True, role="master", sample_rate_hz=16000, bits_per_sample=16, channels=1, format="i2s")
    assert cfg.validate() == []


def test_i2s_validate_bad_role() -> None:
    cfg = I2SConfig(role="nonsense")
    assert any("role" in issue for issue in cfg.validate())
