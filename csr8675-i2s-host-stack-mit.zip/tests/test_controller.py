# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from csr8675_i2s_toolkit.controller import MockTransport, ModuleController
from csr8675_i2s_toolkit.profiles import DeviceProfile
from csr8675_i2s_toolkit.state import HostState, Screen


def test_dial_flow() -> None:
    controller = ModuleController(MockTransport(), DeviceProfile(), HostState())
    controller.handle_key("1")
    controller.handle_key("5")
    controller.handle_key("5")
    controller.handle_key("5")
    controller.handle_key("SEND")
    assert controller.state.screen == Screen.ACTIVE_CALL
    assert controller.state.in_call is True


def test_incoming_flow() -> None:
    controller = ModuleController(MockTransport(), DeviceProfile(), HostState())
    controller.apply_line("RING")
    controller.apply_line('+CLIP: "Mom"')
    assert controller.state.screen == Screen.INCOMING
    assert controller.state.caller_id == "Mom"
