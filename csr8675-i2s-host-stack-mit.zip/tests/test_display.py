# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from csr8675_i2s_toolkit.display import DisplayBuffer


def test_display_writes_text() -> None:
    display = DisplayBuffer(width=10, height=2)
    display.write(0, 1, "ABC")
    assert "ABC" in display.render()
