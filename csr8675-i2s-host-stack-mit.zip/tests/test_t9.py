# SPDX-License-Identifier: MIT
# Copyright (c) 2026 OpenAI

from csr8675_i2s_toolkit.t9 import T9Composer


def test_t9_cycle() -> None:
    composer = T9Composer()
    assert composer.press("5") == "J"
    assert composer.press("5") == "K"
    assert composer.press("5") == "L"
    composer.commit()
    assert composer.press("6") == "LM"
