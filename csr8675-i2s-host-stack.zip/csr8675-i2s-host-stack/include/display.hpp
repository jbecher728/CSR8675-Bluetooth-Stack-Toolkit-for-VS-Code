#pragma once

#include <string>
#include <vector>

namespace csr8675 {

class DisplayBuffer {
  public:
    DisplayBuffer(int width, int height);
    void clear();
    void write(int row, int col, const std::string& text);
    [[nodiscard]] std::string render() const;

  private:
    int width_;
    int height_;
    std::vector<std::string> rows_;
};

}  // namespace csr8675
