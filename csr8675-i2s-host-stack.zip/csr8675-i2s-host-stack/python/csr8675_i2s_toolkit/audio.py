from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class I2SConfig:
    enabled: bool = True
    role: str = "master"
    sample_rate_hz: int = 16000
    bits_per_sample: int = 16
    channels: int = 1
    format: str = "i2s"

    def validate(self) -> list[str]:
        issues: list[str] = []
        if self.role not in {"master", "slave"}:
            issues.append(f"unsupported I2S role: {self.role}")
        if self.sample_rate_hz not in {8000, 16000, 32000, 44100, 48000}:
            issues.append(f"uncommon sample rate: {self.sample_rate_hz}")
        if self.bits_per_sample not in {16, 24, 32}:
            issues.append(f"unsupported bit depth: {self.bits_per_sample}")
        if self.channels not in {1, 2}:
            issues.append(f"unsupported channel count: {self.channels}")
        if self.format not in {"i2s", "left-justified", "pcm"}:
            issues.append(f"unsupported format: {self.format}")
        return issues

    def summary(self) -> str:
        mode = "off" if not self.enabled else f"{self.role} {self.sample_rate_hz}Hz {self.bits_per_sample}-bit {self.channels}ch {self.format}"
        return f"I2S: {mode}"
