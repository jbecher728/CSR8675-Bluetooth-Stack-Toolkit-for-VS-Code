from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from .events import EventParser, ModuleEvent
from .profiles import DeviceProfile
from .state import HostState, Screen


class CommandTransport(Protocol):
    def exchange(self, command: str, line_ending: str = "\r\n") -> str: ...


@dataclass(slots=True)
class ModuleController:
    transport: CommandTransport
    profile: DeviceProfile
    state: HostState
    parser: EventParser = field(init=False)

    def __post_init__(self) -> None:
        self.parser = EventParser(self.profile)

    def send(self, command_key: str, **kwargs: str) -> str:
        command = self.profile.render_command(command_key, **kwargs)
        return self.transport.exchange(command, self.profile.line_ending)

    def info(self) -> str:
        return self.send("info")

    def answer(self) -> str:
        reply = self.send("answer")
        self.state.in_call = True
        self.state.screen = Screen.ACTIVE_CALL
        return reply

    def hangup(self) -> str:
        reply = self.send("hangup")
        self.state.in_call = False
        self.state.screen = Screen.HOME
        self.state.dial_buffer = ""
        return reply

    def dial(self, number: str) -> str:
        reply = self.send("dial", number=number)
        self.state.dial_buffer = number
        self.state.caller_id = number
        self.state.in_call = True
        self.state.screen = Screen.ACTIVE_CALL
        return reply

    def volume_up(self) -> str:
        reply = self.send("volume_up")
        self.state.volume = min(self.state.volume + 1, 15)
        return reply

    def volume_down(self) -> str:
        reply = self.send("volume_down")
        self.state.volume = max(self.state.volume - 1, 0)
        return reply

    def apply_line(self, line: str) -> ModuleEvent:
        event = self.parser.parse(line)
        if event.kind == "incoming_call":
            self.state.screen = Screen.INCOMING
            self.state.in_call = False
        elif event.kind == "caller_id":
            self.state.caller_id = event.payload
        elif event.kind == "call_active":
            self.state.in_call = True
            self.state.screen = Screen.ACTIVE_CALL
        elif event.kind == "call_ended":
            self.state.in_call = False
            self.state.screen = Screen.HOME
            self.state.dial_buffer = ""
        elif event.kind == "linked":
            self.state.linked = True
        elif event.kind == "unlinked":
            self.state.linked = False
        return event

    def handle_key(self, key: str) -> str:
        key = key.upper()
        if key == "LINK_ON":
            self.state.linked = True
        elif key == "LINK_OFF":
            self.state.linked = False
        elif key == "RING":
            self.apply_line(self.profile.event_prefixes["incoming_call"])
        elif key == "MESSAGES":
            self.state.screen = Screen.MESSAGES
            self.state.unread_messages = 0
        elif key == "CONTACTS":
            self.state.screen = Screen.CONTACTS
        elif key == "BACK":
            if self.state.screen == Screen.DIALER:
                self.state.dial_buffer = self.state.dial_buffer[:-1]
            elif self.state.screen == Screen.MESSAGES:
                self.state.composed_message = self.state.t9.backspace()
            else:
                self.state.screen = Screen.HOME
        elif key == "SEND":
            if self.state.screen == Screen.DIALER and self.state.dial_buffer:
                self.dial(self.state.dial_buffer)
            elif self.state.screen == Screen.INCOMING:
                self.answer()
            elif self.state.screen == Screen.MESSAGES:
                self.state.unread_messages += 1
                self.state.t9.commit()
                self.state.screen = Screen.HOME
        elif key == "HANGUP":
            self.hangup()
        elif key == "UP":
            self.volume_up()
        elif key == "DOWN":
            self.volume_down()
        elif key.isdigit() or key in {"*", "#"}:
            self._handle_symbol(key)
        return self.state.render()

    def _handle_symbol(self, key: str) -> None:
        if self.state.screen == Screen.HOME:
            if key == "1":
                self.state.screen = Screen.DIALER
            elif key == "2":
                self.state.screen = Screen.MESSAGES
            elif key == "3":
                self.state.screen = Screen.CONTACTS
            return
        if self.state.screen in {Screen.DIALER, Screen.ACTIVE_CALL}:
            if key.isdigit() or key in {"*", "#"}:
                if self.state.screen != Screen.ACTIVE_CALL:
                    self.state.dial_buffer += key
                    self.state.screen = Screen.DIALER
        elif self.state.screen == Screen.MESSAGES:
            if key.isdigit():
                self.state.composed_message = self.state.t9.press(key)


class MockTransport:
    def __init__(self) -> None:
        self.history: list[str] = []

    def exchange(self, command: str, line_ending: str = "\r\n") -> str:
        self.history.append(command + line_ending)
        if command.startswith("ATD"):
            return "OK DIAL"
        if command in {"ATA", "ATH", "AT+VOLUP", "AT+VOLDOWN"}:
            return "OK"
        return "OK INFO"
