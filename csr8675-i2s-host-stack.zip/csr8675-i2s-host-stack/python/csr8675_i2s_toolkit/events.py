from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .profiles import DeviceProfile

EventType = Literal["incoming_call", "caller_id", "call_active", "call_ended", "linked", "unlinked", "ok", "error", "unknown"]


@dataclass(slots=True)
class ModuleEvent:
    kind: EventType
    raw: str
    payload: str = ""


class EventParser:
    def __init__(self, profile: DeviceProfile) -> None:
        self.profile = profile

    def parse(self, line: str) -> ModuleEvent:
        text = line.strip()
        prefixes = self.profile.event_prefixes
        for kind in ("incoming_call", "call_active", "call_ended", "linked", "unlinked", "ok", "error"):
            if text.startswith(prefixes[kind]):
                return ModuleEvent(kind=kind, raw=text)
        cid_prefix = prefixes["caller_id"]
        if text.startswith(cid_prefix):
            payload = text[len(cid_prefix):].strip().strip('"')
            return ModuleEvent(kind="caller_id", raw=text, payload=payload)
        return ModuleEvent(kind="unknown", raw=text, payload=text)
