from __future__ import annotations

from dataclasses import dataclass

VALID_KEYS = set("0123456789*#") | {"SEND", "HANGUP", "UP", "DOWN", "LEFT", "RIGHT", "OK", "BACK", "CONTACTS", "MESSAGES", "LINK_ON", "LINK_OFF", "RING"}


@dataclass(slots=True)
class KeyEvent:
    key: str

    def normalized(self) -> str:
        value = self.key.strip().upper()
        if value not in VALID_KEYS:
            raise ValueError(f"unsupported key: {self.key}")
        return value
