from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class LedState:
    link: str = "off"
    call: str = "off"
    message: str = "off"

    def summary(self) -> str:
        return f"LED link={self.link} call={self.call} msg={self.message}"


def apply_policy(linked: bool, in_call: bool, has_unread: bool) -> LedState:
    return LedState(
        link="solid" if linked else "blink-slow",
        call="solid" if in_call else "off",
        message="pulse" if has_unread else "off",
    )
