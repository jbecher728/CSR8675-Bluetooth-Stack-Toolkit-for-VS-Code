from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import serial
import serial.tools.list_ports


@dataclass(slots=True)
class SerialTransport:
    port: str
    baudrate: int = 115200
    timeout: float = 1.0

    def exchange(self, command: str, line_ending: str = "\r\n") -> str:
        with serial.Serial(self.port, self.baudrate, timeout=self.timeout) as ser:
            ser.write((command + line_ending).encode("utf-8"))
            ser.flush()
            return ser.read_until(expected=b"\n").decode("utf-8", errors="replace").strip()

    def monitor(self) -> Iterable[str]:
        with serial.Serial(self.port, self.baudrate, timeout=self.timeout) as ser:
            while True:
                line = ser.readline()
                if not line:
                    break
                yield line.decode("utf-8", errors="replace").strip()


def list_serial_ports() -> list[str]:
    return [port.device for port in serial.tools.list_ports.comports()]
