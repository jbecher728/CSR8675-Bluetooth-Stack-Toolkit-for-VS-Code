from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .audio import I2SConfig
from .display import DisplayBuffer
from .leds import LedState, apply_policy
from .t9 import T9Composer


class Screen(str, Enum):
    HOME = "HOME"
    DIALER = "DIALER"
    INCOMING = "INCOMING"
    ACTIVE_CALL = "ACTIVE_CALL"
    MESSAGES = "MESSAGES"
    CONTACTS = "CONTACTS"


@dataclass(slots=True)
class HostState:
    screen: Screen = Screen.HOME
    linked: bool = False
    in_call: bool = False
    unread_messages: int = 0
    signal: str = "--"
    dial_buffer: str = ""
    caller_id: str = ""
    composed_message: str = ""
    volume: int = 8
    i2s: I2SConfig = field(default_factory=I2SConfig)
    t9: T9Composer = field(default_factory=T9Composer)
    leds: LedState = field(default_factory=LedState)

    def update_leds(self) -> None:
        self.leds = apply_policy(self.linked, self.in_call, self.unread_messages > 0)

    def render(self) -> str:
        self.update_leds()
        display = DisplayBuffer()
        display.write_centered(0, "RETRO CAR PHONE")
        display.write(1, 1, f"BT: {'LINK' if self.linked else 'WAIT'}")
        display.write(1, 12, f"VOL:{self.volume:02d}")
        display.write(2, 1, self.i2s.summary()[:20])
        if self.screen == Screen.HOME:
            display.write(4, 1, "1 Dial  2 Msg")
            display.write(5, 1, "3 Contacts")
            display.write(6, 1, self.leds.summary()[:20])
        elif self.screen == Screen.DIALER:
            display.write(3, 1, "Dial:")
            display.write(4, 1, self.dial_buffer[-20:])
            display.write(6, 1, "SEND call BACK clr")
        elif self.screen == Screen.INCOMING:
            display.write(3, 1, "Incoming call")
            display.write(4, 1, self.caller_id[:20] or "Unknown")
            display.write(6, 1, "SEND ans HANGUP rej")
        elif self.screen == Screen.ACTIVE_CALL:
            display.write(3, 1, "Active call")
            display.write(4, 1, self.caller_id[:20] or self.dial_buffer[:20])
            display.write(6, 1, "HANGUP to end")
        elif self.screen == Screen.MESSAGES:
            display.write(3, 1, "Message:")
            display.write(4, 1, self.composed_message[-20:])
            display.write(6, 1, "digits T9 SEND/BACK")
        elif self.screen == Screen.CONTACTS:
            display.write(3, 1, "Contacts")
            display.write(4, 1, "1 Mom 2 Office")
            display.write(6, 1, "SEND to dial")
        return display.render()
