#include "display.hpp"

#include <iostream>

int main() {
    csr8675::DisplayBuffer display(24, 8);
    display.write(0, 1, "CSR8675 I2S HOST STACK");
    display.write(2, 1, "BT: LINKED");
    display.write(3, 1, "AUDIO: I2S 16k/16b");
    display.write(4, 1, "UI: T9 READY");
    std::cout << display.render();
    return 0;
}
