from csr8675_i2s_toolkit.events import EventParser
from csr8675_i2s_toolkit.profiles import DeviceProfile


def test_parse_caller_id() -> None:
    parser = EventParser(DeviceProfile())
    event = parser.parse('+CLIP: "5551234"')
    assert event.kind == "caller_id"
    assert "5551234" in event.payload
